$(document).ready(function() {
	$('#makeDonationForm select').material_select();
});